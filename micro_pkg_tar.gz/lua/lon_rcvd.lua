-- lua demo stricpt
-- Speicherort fuer Aufruf: /usr/bin/

-- data, max. 221 byte, erstes zeichen data_len, zweites zeichen msg_code
--rawdata = lua_rcvd_msg()
--data = lua_hexstring2string(rawdata)
