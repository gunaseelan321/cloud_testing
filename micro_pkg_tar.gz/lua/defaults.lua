wr_channels = {}
wrs = {}
wr_errors = {}
wr_status = {}
loggedETotal={}
MCValues={}
